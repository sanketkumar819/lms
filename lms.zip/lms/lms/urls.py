"""lms URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from library import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('student/',views.student_view,name='allrecords'),
    path('',views.index,name='home'),
    path('register/',views.signupadmin, name='signup'),
    path('login/',views.adminlogin, name='signin'),
    path('logout/',views.logout, name='signout'),
    path("addbook/", views.AddBook.as_view(), name='addbook'),
    path('viewbook/',views.view_books, name='viewbook'),
    path("addbook/<int:pk>/", views.upproduct.as_view(), name='edit_book'),
    path('delete_book/<int:myid>/',views.delete_book, name='delete_book')
]
