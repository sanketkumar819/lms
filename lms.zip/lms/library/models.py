from django.db import models
from django.urls import reverse

# Create your models here.
class Book(models.Model):
    name = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    category = models.CharField(max_length=50)

    def __str__(self):
        return str(self.name)
        
    def get_absolute_url(self):
        return reverse("home")

class Admin(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=200,default=0)
    def __str__(self):
        return f'name:{self.name}'
        
    
        
    
