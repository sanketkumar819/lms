from .models import Admin
from django import forms
from django.contrib.auth.hashers import check_password
from django.forms import fields
from django.contrib.auth.hashers import check_password

class Adminsignup(forms.ModelForm):
    password= forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}))
    retype_password=forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model = Admin
        fields= ['name','email']
        widgets = {
        'name':forms.TextInput(attrs={'class':'form-control'}),
        'email':forms.TextInput(attrs={'class':'form-control'}),
        }
    def clean(self):
        super().clean()
        p = self.cleaned_data.get('password')
        p1 = self.cleaned_data.get('retype_password')
        if p!=p1 or len(p)<6:
            raise forms.ValidationError("Both password did not match")


class Adminlogin(forms.Form):
    email=forms.EmailField()
    password=forms.CharField(widget=forms.PasswordInput)
    def clean(self):
        e=self.cleaned_data.get("email")
        p=self.cleaned_data.get("password")
        try:
            sel=Admin.objects.get(email=e)
        except:
            raise forms.ValidationError("user doesnot exit")
        else:
            if not check_password(p,sel.password):
                raise forms.ValidationError("password doesnot match")
