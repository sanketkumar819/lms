from django.shortcuts import render,redirect
from django.forms import forms
from django.http import HttpResponse
from .forms import Adminlogin, Adminsignup 
from django.contrib.auth.hashers import make_password
from django.views.generic import ListView,CreateView,UpdateView,DeleteView, DetailView
from .models import Book, Admin
from .serializers import BookSerializer
from rest_framework import viewsets
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated,IsAdminUser
#from django.urls import reverse_lazy

# Create your views here.

def index(request):

    return render(request,'library/index.html')


def signupadmin(request):
     f=Adminsignup( request.POST or None )
     if f.is_valid(): # we are calling the clean method
          adn = f.save(commit=False)
          p = f.cleaned_data['password']
          encp = make_password(p)
          adn.password = encp
          adn.save()
          return redirect("library:signin")
          
     return render(request,'library/adminreg.html',{'form':f})


def adminlogin(request):
     f = Adminlogin( request.POST or None)
     if f.is_valid(): # we are calling the clean method
          e=f.cleaned_data.get("email")
          obj = Admin.objects.get(email=e)
          request.session['user_log']={'username':obj.email}
          return redirect("home")
     return render(request,"library/adminreg.html", {'form':f})


def logout(request):
     request.session.pop("user_log")
     return redirect("home")
     
     
class AddBook(CreateView):
     template_name = 'library/addbook.html'
     model = Book
     fields = ['name','author','category']
     context_object_name='form'
     def form_valid(self,form):
          return super().form_valid(form)


def view_books(request):
    books = Book.objects.all()
    return render(request, "library/view_book.html", {'books':books})

def student_view(request):
    books = Book.objects.all()
    return render(request, "library/student_view_book.html", {'books':books})


class upproduct(UpdateView):
    template_name = 'library/addbook.html'
    model = Book
    fields = ['name','author','category']
    context_object_name='form'
     
     
def delete_book(request, myid):
    books = Book.objects.filter(id=myid)
    books.delete()
    return redirect("/viewbook")

class BookModelViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    authentication_classes = [BasicAuthentication]
    permission_classes = [IsAdminUser]

